# Assistant fiscal français pour Claude.ai

Cet assistant t'aide à comprendre et optimiser ta situation fiscale française
directement dans Claude.ai, pour la déclaration 2026 (revenus 2025).

**Version :** 1.0.0 — **Mis à jour :** 8 avril 2026

## Installation en 3 étapes

### Étape 1 — Connecter le serveur de calcul (MCP)

1. Dans Claude.ai, clique sur ton avatar en haut à droite → **Paramètres**
2. Va dans **Connecteurs** → **Ajouter un connecteur personnalisé**
3. Dans le champ URL, colle :
   ```
   https://kalifa.happykiller.net/mcp
   ```
4. Donne-lui le nom `Fiscal FR` et clique **Ajouter**

> **Plan Free ?** Tu as droit à 1 connecteur personnalisé.
> L'assistant fonctionne aussi sans connecteur (calculs manuels depuis les barèmes intégrés),
> mais les résultats seront moins précis et personnalisés.

### Étape 2 — Installer la compétence

1. Dans **Paramètres** → **Personnaliser** → **Compétences**
2. Clique **Téléverser une compétence**
3. Sélectionne le fichier `fiscal-fr-claudeai-v1.0.0.zip`
4. La compétence apparaît dans ta liste ✅

### Étape 3 — Tester l'installation

Démarre une nouvelle conversation et pose cette question :

> *"Peux-tu faire un diagnostic fiscal de ma situation ? Je suis célibataire,
> salarié(e), je gagne environ 40 000 € par an."*

Claude doit activer automatiquement l'assistant fiscal et te poser
des questions complémentaires sur ta situation.

---

## Ce que l'assistant peut faire

| Fonctionnalité | Description |
|---|---|
| **Qualification fiscale** | Analyse ta situation, détecte la complexité, identifie les périmètres couverts |
| **Arbitrages fiscaux** | Compare PFU vs barème, frais réels vs forfait 10 %, micro-foncier vs régime réel |
| **Checklist justificatifs** | Liste les documents obligatoires, recommandés et manquants |
| **Points de vigilance** | Repère les incohérences, régimes à trancher, cas hors périmètre |
| **Pré-déclaration** | Produit un brouillon structuré avec codes cases et origines tracées |
| **Estimation IR** | Calcule une estimation indicative de l'impôt (barème progressif, quotient familial, décote, crédits) |
| **Copilote de saisie** | Guide écran par écran sur impots.gouv.fr, étape par étape |

---

## Mise à jour

Pour mettre à jour vers une nouvelle version :
1. Télécharge le nouveau ZIP depuis le dépôt GitHub
2. Dans **Paramètres** → **Compétences**, supprime l'ancienne version
3. Uploade le nouveau ZIP

---

## Limitations

- Les calculs sont indicatifs — toujours vérifier sur impots.gouv.fr
- Données fiscales valables pour la campagne 2026 — vérifier en cas de changement de loi
- Ne remplace pas un expert-comptable pour les situations complexes (revenus étrangers, crypto, contrôle fiscal)
- Pas de dépôt automatique de déclaration

---

## Problèmes fréquents

**L'assistant ne s'active pas automatiquement**
→ Mentionne explicitement "fiscal", "impôts" ou "déclaration" dans ta question

**Le connecteur MCP ne se connecte pas**
→ Vérifie que ton plan Claude supporte les connecteurs (Free = 1 max)
→ Essaie de retirer et re-ajouter le connecteur avec l'URL exacte ci-dessus

**Les calculs semblent incorrects**
→ Vérifie la version de la compétence — une mise à jour est peut-être disponible
→ Contrôle tes montants saisis (les calculs sont basés sur ce que tu as déclaré)

---

*Projet open source : https://github.com/happykiller/agent-friendly-resources*
*Signaler un problème : https://github.com/happykiller/agent-friendly-resources/issues*
