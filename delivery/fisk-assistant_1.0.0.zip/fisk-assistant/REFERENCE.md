# Référence fiscale française 2026

> Données valables pour la déclaration de revenus 2026
> (revenus perçus en 2025).
> Sources : impots.gouv.fr, legifrance.gouv.fr, service-public.fr

## Barème IR 2026

Barème applicable aux revenus 2025 (CGI art. 197 — LF 2026).

| Tranche de revenu net imposable (par part) | Taux |
|---|---|
| Jusqu'à 11 600 € | 0 % |
| De 11 601 € à 29 579 € | 11 % |
| De 29 580 € à 84 577 € | 30 % |
| De 84 578 € à 181 917 € | 41 % |
| Au-delà de 181 917 € | 45 % |

Source : https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000053542636

### Quotient familial

| Situation | Parts |
|---|---|
| Célibataire / divorcé / veuf sans enfant | 1 part |
| Marié / Pacsé sans enfant | 2 parts |
| + 1er enfant à charge exclusive | + 0,5 part |
| + 2e enfant à charge exclusive | + 0,5 part |
| + 3e enfant et suivants (charge exclusive) | + 1 part par enfant |
| Enfant en garde alternée | + 0,25 part par enfant |
| Parent isolé (1re part spécifique) | + 0,5 part |

**Plafond de l'avantage** : **1 807 €** par demi-part supplémentaire
**Plafond parent isolé** (1re part spécifique) : **4 262 €**

Source : https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000033817781

### Décote 2026

| Situation | Seuil d'impôt brut | Calcul |
|---|---|---|
| Célibataire | 1 982 € | 897 € − (impôt brut × 45,25 %) |
| Couple | 3 277 € | 1 483 € − (impôt brut × 45,25 %) |

### Abattements automatiques

| Type de revenu | Taux | Plancher | Plafond |
|---|---|---|---|
| Salaires (par déclarant) | 10 % | 509 € | 14 555 € |
| Pensions (par pensionné, plafond foyer) | 10 % | 454 € | 4 439 € (foyer) |
| Micro-foncier (recettes brutes ≤ 15 000 €) | 30 % | — | — |
| Dividendes (option barème) | 40 % | — | — |
| Micro-entrepreneur BIC vente | 71 % | 305 € | — |
| Micro-entrepreneur BIC services | 50 % | 305 € | — |
| Micro-entrepreneur BNC libéral | 34 % | 305 € | — |

Source : https://simulateur-ir-ifi.impots.gouv.fr/calcul_impot/2026/aides/frais.htm

### PFU (Prélèvement Forfaitaire Unique) 2026

Applicable aux revenus du capital (intérêts, dividendes) perçus à partir de 2026 :
- **Taux global : 31,4 %** (12,8 % IR + 18,6 % prélèvements sociaux)
- Option barème progressif possible (à comparer selon TMI)

Pour revenus du capital perçus en 2025 soumis en déclaration 2026 : vérifier le taux applicable (transition 30 % → 31,4 % selon type de revenu et date de perception).

Source : https://entreprendre.service-public.gouv.fr/actualites/A18796

---

## Plafonds épargne

### PER (Plan Épargne Retraite)
- Plafond déductible : **10 % des revenus professionnels nets** de l'année précédente
- Plafond maximum : **35 194 €** pour les versements 2025 [À VÉRIFIER POUR L'ANNÉE EN COURS]
- Plafond alternatif (sans revenus professionnels) : **4 399 €** [À VÉRIFIER]
- Versements non déduits : ouvrent droit à exonération à la sortie

### PEA
- Plafond versements : **150 000 €**
- PEA-PME : **225 000 €** (cumulé PEA + PEA-PME)

### Livrets réglementés (taux en vigueur au 1er février 2025)

| Livret | Taux | Plafond |
|---|---|---|
| Livret A | 2,4 % [À VÉRIFIER] | 22 950 € |
| LDDS | 2,4 % [À VÉRIFIER] | 12 000 € |
| LEP | 3,5 % [À VÉRIFIER] | 10 000 € |

> Les taux des livrets réglementés sont révisables. Vérifier le taux en vigueur sur service-public.fr.

---

## Dispositifs de défiscalisation

### Pinel
Le dispositif Pinel s'est terminé le **31 décembre 2024**.
Aucun nouveau investissement Pinel n'est possible pour les revenus 2025.
Les investissements réalisés avant cette date continuent de générer des réductions d'impôt selon les engagements en cours.
Taux de réduction selon durée d'engagement initial (6/9/12 ans) — se référer au contrat initial.

### Dons et réductions d'impôt

| Type de don | Taux de réduction | Plafond |
|---|---|---|
| Organismes d'intérêt général (case 7UF) | 66 % | 20 % du revenu imposable |
| Associations d'aide aux personnes en difficulté — Coluche (case 7UD) | 75 % | **2 000 €** (depuis le 14/10/2025) |

> Au-delà du plafond Coluche, l'excédent bascule automatiquement en réduction 66 %.
> Source : https://www.service-public.gouv.fr/particuliers/actualites/A18836

### Frais réels vs déduction forfaitaire

- Déduction forfaitaire automatique : **10 %** des salaires bruts (plancher 509 €, plafond 14 555 € par déclarant)
- Opter pour les frais réels si dépenses réelles justifiées > déduction forfaitaire calculée
- Frais déductibles : déplacements domicile-travail, repas, double résidence, formation

---

## Crédits d'impôt

### Garde d'enfant (hors du domicile)
- Taux : **50 %** des dépenses engagées
- Plafond de dépenses : **3 500 €** par enfant à charge exclusive (1 750 € en garde alternée)
- Crédit maximum : 1 750 € par enfant (875 € en alternée)

### Emploi à domicile
- Taux : **50 %** des dépenses
- Plafond de base : **12 000 €**
- Majoration : + 1 500 € par enfant à charge, + 1 500 € par membre du foyer ≥ 65 ans
- Plafond avec majorations : 15 000 € (20 000 € en cas d'invalidité)

---

## Contribution Exceptionnelle sur les Hauts Revenus (CEHR)

| Situation | Tranche | Taux |
|---|---|---|
| Célibataire | 0 – 250 000 € | 0 % |
| Célibataire | 250 001 – 500 000 € | 3 % |
| Célibataire | > 500 000 € | 4 % |
| Couple | 0 – 500 000 € | 0 % |
| Couple | 500 001 – 1 000 000 € | 3 % |
| Couple | > 1 000 000 € | 4 % |

---

## Dates clés 2026

| Événement | Date |
|---|---|
| Ouverture déclaration en ligne | 9 avril 2026 |
| Clôture — départements 01 à 19 et non-résidents | 21 mai 2026 |
| Clôture — départements 20 à 54 | 28 mai 2026 |
| Clôture — départements 55 à 976 | 4 juin 2026 |
| Avis d'imposition disponibles | Été 2026 [À VÉRIFIER] |

---

## Sources officielles
- Déclaration en ligne : https://www.impots.gouv.fr/particulier/declarez-en-ligne
- Barèmes officiels : https://www.service-public.fr/particuliers/vosdroits/F1419
- Simulateur officiel DGFiP : https://simulateur-ir-ifi.impots.gouv.fr/calcul_impot/2026/
- CGI art. 197 (barème IR) : https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000053542636
- Crédits d'impôt famille et domicile : https://www.service-public.gouv.fr/particuliers/vosdroits/F8
